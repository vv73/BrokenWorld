/** Automatically generated file. DO NOT MODIFY */
package com.eddygao.mysolitaire;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}