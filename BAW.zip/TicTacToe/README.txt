README

Just a Tic Tac Toe game I created. complete with AI! Let me know what you think! Justin@jcrastelli.com